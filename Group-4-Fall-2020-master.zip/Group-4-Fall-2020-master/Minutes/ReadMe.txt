This directory should hold all meeting minutes for this group.

Please upload a fresh file for each week's meeting minutes, with the 
date of submission as part of the file name.

The sample provided is an example format.  Alternatives are acceptable,
provided that they are clear and easy to follow, and that they clearly
document recent activities and action items for each team member.
