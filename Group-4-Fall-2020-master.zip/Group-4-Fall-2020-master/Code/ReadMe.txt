This directory should hold all files related to the Coding project.

The Adventure Game Scenario is provided as a sample of a good scenario.
It has a clear meaningful title describing THIS scenario for THIS project.
The group number and members are clearly listed.
It clearly describes what one expects to see when the release is demonstrated.
Please follow a similar format when writing your scenarios. ( 2 pages, margins, fonts, etc. )

Note:  Please DO NOT store entire development libraries in the code repository that you 
did not develop yourselves, especially if they can be easily downloaded from the Internet.
Instead include a ReadMe file documenting instructions for how to download such libraries.
Include here files that your group either created or edited, and instructions on how and where
to get anything else that may be needed to build your project.
